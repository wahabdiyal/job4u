<?php

namespace App\Http\Controllers;

use App\Models\JobRegister;
use Illuminate\Http\Request;

class JobRegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\JobRegister  $jobRegister
     * @return \Illuminate\Http\Response
     */
    public function show(JobRegister $jobRegister)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\JobRegister  $jobRegister
     * @return \Illuminate\Http\Response
     */
    public function edit(JobRegister $jobRegister)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\JobRegister  $jobRegister
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, JobRegister $jobRegister)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\JobRegister  $jobRegister
     * @return \Illuminate\Http\Response
     */
    public function destroy(JobRegister $jobRegister)
    {
        //
    }
}
