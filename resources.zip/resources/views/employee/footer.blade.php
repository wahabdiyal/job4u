
    <footer class="bg-dark text-white">
        <div class="container py-3">
            <div class="row">
                <div class="col-lg-3">
                    <h4>Jobs For You</h4>
                    <p>Lorem Ipsum is simply dummy Employer Login Browser Company
                        text of the printing and
                        typesetting industry. Lorem
                        Ipsum has been .</p>
                </div>
                <div class="col-lg-3 footerh4class">
                    <h4 class="footerh4">Employers</h4>
                    <ul class="navbar-nav">
                        <li class="nav-item foota">

                            <a class="nav-link" href="#">Employer Login</a>

                        </li>
                        <li class="nav-item foota">

                            <a class="nav-link" href="#">Job Posting</a>

                        </li>
                        <li class="nav-item foota">

                            <a class="nav-link" href="#">Job Posting</a>

                        </li>
                    </ul>
                </div>
                <div class="col-lg-3 footerh4class">
                    <h4>Browse Jobs</h4>
                    <ul class="navbar-nav">
                        <li class="nav-item foota">

                            <a class="nav-link" href="#">Employer Login</a>

                        </li>
                        <li class="nav-item foota">

                            <a class="nav-link" href="#">Job Posting</a>

                        </li>
                        <li class="nav-item foota">

                            <a class="nav-link" href="#">Job Posting</a>

                        </li>
                    </ul>


                </div>
                <div class="col-lg-3 footerh4class">
                    <h4>Browse Jobs</h4>
                    <ul class="navbar-nav">
                        <li class="nav-item foota">

                            <a class="nav-link" href="#">Employer Login</a>

                        </li>
                        <li class="nav-item foota">

                            <a class="nav-link" href="#">Job Posting</a>

                        </li>
                        <li class="nav-item foota">

                            <a class="nav-link" href="#">Job Posting</a>

                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </footer>
